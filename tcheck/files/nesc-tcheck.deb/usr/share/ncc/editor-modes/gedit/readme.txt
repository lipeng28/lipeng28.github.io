Date: Wed, 19 Dec 2007 09:41:51 -0500
From: "Ariel Mauricio Nunez Gomez" <ingenieroariel@gmail.com>
Subject: Re: [Tinyos-help] Adding NesC syntax files to tinyos debs

I just checked and there was no one for Gedit. This is the one I created
based on the cpp one.

It goes in /usr/share/gtksourceview-2.0/language-specs/ncc.lang on Ubuntu
Gutsy.

I doesn't (yet) automatically apply the style to .nc files (you have to
check View-> Highlight mode -> Sources -> NesC) I have been playing with
mimetypes, but no luck yet.

Regards,
Ariel.
