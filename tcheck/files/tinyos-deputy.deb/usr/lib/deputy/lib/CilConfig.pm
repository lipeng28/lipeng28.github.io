
$::archos    = "x86_LINUX";
$::cc        = "gcc";
$::cilhome   = "/home/hanjo/rpmbuild/BUILD/tinyos-deputy-1.1/cil";
$::default_mode = "GNUCC";

